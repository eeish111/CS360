package com.example.jquinatamodule3;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WeightActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    private TableLayout tableWeights;
    private TextView textCurrentWeight;
    private TextView textGoalWeight;
    private EditText editNewWeight;

    private Button buttonAddWeight;
    private Button buttonChangeGoal;
    private Button buttonSmsSettings;

    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_weight);

        userId = getIntent().getIntExtra("USER_ID", -1);

        databaseHelper = new DatabaseHelper(this);

        tableWeights = findViewById(R.id.tableWeights);
        textCurrentWeight = findViewById(R.id.textCurrentWeight);
        textGoalWeight = findViewById(R.id.textGoalWeight);
        editNewWeight = findViewById(R.id.editNewWeight);

        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonChangeGoal = findViewById(R.id.buttonChangeGoal);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        buttonAddWeight.setOnClickListener(v -> addWeight());

        buttonChangeGoal.setOnClickListener(v -> changeGoal());

        buttonSmsSettings.setOnClickListener(v -> openSmsSettings());

        loadWeights();
        displayGoal();
    }

    private void addWeight() {

        String weightInput =
                editNewWeight.getText().toString().trim();

        if (weightInput.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter your weight.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        double weight;

        try {
            weight = Double.parseDouble(weightInput);

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Enter a valid weight.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String currentDate =
                new SimpleDateFormat(
                        "MM/dd/yyyy",
                        Locale.getDefault()
                ).format(new Date());

        long result =
                databaseHelper.addWeight(
                        userId,
                        currentDate,
                        weight
                );

        if (result != -1) {

            Toast.makeText(
                    this,
                    "Weight added.",
                    Toast.LENGTH_SHORT
            ).show();

            editNewWeight.setText("");

            loadWeights();
            checkGoalWeight(weight);
        }
    }

    private void loadWeights() {

        while (tableWeights.getChildCount() > 1) {
            tableWeights.removeViewAt(1);
        }

        Cursor cursor =
                databaseHelper.getAllWeights(userId);

        while (cursor.moveToNext()) {

            int weightId =
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow("id")
                    );

            String date =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow("date")
                    );

            double weight =
                    cursor.getDouble(
                            cursor.getColumnIndexOrThrow("weight")
                    );

            addWeightRow(
                    weightId,
                    date,
                    weight
            );
        }

        cursor.close();

        double latestWeight =
                databaseHelper.getLatestWeight(userId);

        if (latestWeight != -1) {

            textCurrentWeight.setText(
                    "Current Weight: " + latestWeight + " kg"
            );

        } else {

            textCurrentWeight.setText(
                    "Current Weight: No Data"
            );
        }
    }

    private void addWeightRow(
            int weightId,
            String date,
            double weight) {

        TableRow row = new TableRow(this);

        TextView dateText = new TextView(this);
        TextView weightText = new TextView(this);

        Button editButton = new Button(this);
        Button deleteButton = new Button(this);

        dateText.setText(date);
        weightText.setText(weight + " kg");

        editButton.setText("Edit");
        deleteButton.setText("Delete");

        dateText.setPadding(8, 8, 8, 8);
        weightText.setPadding(8, 8, 8, 8);

        editButton.setOnClickListener(v ->
                showEditWeightDialog(
                        weightId,
                        date,
                        weight
                ));

        deleteButton.setOnClickListener(v -> {

            databaseHelper.deleteWeight(weightId);

            Toast.makeText(
                    this,
                    "Weight deleted.",
                    Toast.LENGTH_SHORT
            ).show();

            loadWeights();
        });

        row.addView(dateText);
        row.addView(weightText);
        row.addView(editButton);
        row.addView(deleteButton);

        tableWeights.addView(row);
    }

    private void showEditWeightDialog(
            int weightId,
            String currentDate,
            double currentWeight) {

        EditText input = new EditText(this);

        input.setInputType(
                android.text.InputType.TYPE_CLASS_NUMBER |
                        android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        );

        input.setText(
                String.valueOf(currentWeight)
        );

        new AlertDialog.Builder(this)
                .setTitle("Edit Weight")
                .setMessage(
                        "Update the weight for " + currentDate
                )
                .setView(input)
                .setPositiveButton(
                        "Save",
                        (dialog, which) -> {

                            String value =
                                    input.getText()
                                            .toString()
                                            .trim();

                            if (!value.isEmpty()) {

                                double newWeight =
                                        Double.parseDouble(value);

                                databaseHelper.updateWeight(
                                        weightId,
                                        currentDate,
                                        newWeight
                                );

                                loadWeights();
                                checkGoalWeight(newWeight);
                            }
                        })
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .show();
    }

    private void changeGoal() {

        EditText input = new EditText(this);

        input.setHint("Goal Weight");

        input.setInputType(
                android.text.InputType.TYPE_CLASS_NUMBER |
                        android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        );

        new AlertDialog.Builder(this)
                .setTitle("Change Goal Weight")
                .setView(input)
                .setPositiveButton(
                        "Save",
                        (dialog, which) -> {

                            String value =
                                    input.getText()
                                            .toString()
                                            .trim();

                            if (!value.isEmpty()) {

                                double goal =
                                        Double.parseDouble(value);

                                databaseHelper.setGoalWeight(
                                        userId,
                                        goal
                                );

                                displayGoal();
                            }
                        })
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .show();
    }

    private void displayGoal() {

        double goal =
                databaseHelper.getGoalWeight(userId);

        if (goal != -1) {

            textGoalWeight.setText(
                    "Goal Weight: " + goal + " kg"
            );

        } else {

            textGoalWeight.setText(
                    "Goal Weight: Not Set"
            );
        }
    }

    private void checkGoalWeight(double currentWeight) {

        double goal =
                databaseHelper.getGoalWeight(userId);

        if (goal == -1) {
            return;
        }

        boolean goalReached =
                Math.abs(currentWeight - goal) < 0.01;

        if (goalReached) {

            Toast.makeText(
                    this,
                    "Congratulations! You reached your goal weight!",
                    Toast.LENGTH_LONG
            ).show();

            sendGoalSms(goal);
        }
    }

    private void sendGoalSms(double goal) {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        String phoneNumber =
                databaseHelper.getPhone(userId);

        if (phoneNumber == null ||
                phoneNumber.isEmpty()) {

            return;
        }

        String message =
                "Congratulations! You reached your goal weight of "
                        + goal + " kg.";

        try {

            SmsManager smsManager =
                    getSystemService(SmsManager.class);

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Goal SMS sent.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "SMS could not be sent.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void openSmsSettings() {

        Intent intent =
                new Intent(
                        this,
                        SmsActivity.class
                );

        intent.putExtra(
                "USER_ID",
                userId
        );

        startActivity(intent);
    }
}