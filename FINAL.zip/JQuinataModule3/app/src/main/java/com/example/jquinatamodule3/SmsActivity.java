package com.example.jquinatamodule3;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText phoneText;

    private Button buttonAllowSms;
    private Button buttonSkipSms;

    private DatabaseHelper databaseHelper;

    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sms);

        databaseHelper =
                new DatabaseHelper(this);

        userId =
                getIntent().getIntExtra(
                        "USER_ID",
                        -1
                );

        phoneText =
                findViewById(R.id.phoneText);

        buttonAllowSms =
                findViewById(R.id.buttonAllowSms);

        buttonSkipSms =
                findViewById(R.id.buttonSkipSms);

        buttonAllowSms.setOnClickListener(
                v -> requestSmsPermission()
        );

        buttonSkipSms.setOnClickListener(
                v -> skipSms()
        );
    }

    private void requestSmsPermission() {

        String phoneNumber =
                phoneText.getText()
                        .toString()
                        .trim();

        if (phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter a phone number first.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        databaseHelper.updatePhone(
                userId,
                phoneNumber
        );

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    "SMS notifications are enabled.",
                    Toast.LENGTH_SHORT
            ).show();

            saveSmsSetupComplete();

            openWeightScreen();

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.SEND_SMS
                    },
                    SMS_PERMISSION_CODE
            );
        }
    }

    private void skipSms() {

        Toast.makeText(
                this,
                "Continuing without SMS notifications.",
                Toast.LENGTH_SHORT
        ).show();

        saveSmsSetupComplete();

        openWeightScreen();
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0]
                            == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(
                        this,
                        "SMS notifications enabled.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "SMS permission denied. The app will continue without notifications.",
                        Toast.LENGTH_LONG
                ).show();
            }

            saveSmsSetupComplete();

            openWeightScreen();
        }
    }

    private void saveSmsSetupComplete() {

        SharedPreferences preferences =
                getSharedPreferences(
                        "app_settings",
                        MODE_PRIVATE
                );

        preferences.edit()
                .putBoolean(
                        "sms_setup_complete_" + userId,
                        true
                )
                .apply();
    }

    private void openWeightScreen() {

        Intent intent =
                new Intent(
                        this,
                        WeightActivity.class
                );

        intent.putExtra(
                "USER_ID",
                userId
        );

        startActivity(intent);

        finish();
    }
}