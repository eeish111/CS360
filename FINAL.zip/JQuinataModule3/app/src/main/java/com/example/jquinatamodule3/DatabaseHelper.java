package com.example.jquinatamodule3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHTS = "weights";
    private static final String TABLE_GOALS = "goal_weights";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE NOT NULL, " +
                        "password TEXT NOT NULL, " +
                        "phone TEXT)";

        String createWeightsTable =
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "date TEXT NOT NULL, " +
                        "weight REAL NOT NULL)";

        String createGoalsTable =
                "CREATE TABLE " + TABLE_GOALS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER UNIQUE NOT NULL, " +
                        "goal_weight REAL NOT NULL)";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightsTable);
        db.execSQL(createGoalsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        onCreate(db);
    }

    // Creates a new user account.
    public long createUser(String username, String password) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        return db.insert(TABLE_USERS, null, values);
    }

    // Checks username and password. Returns user ID if login is correct.
    public int checkUser(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{"id"},
                "username=? AND password=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        int userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id")
            );
        }

        cursor.close();

        return userId;
    }

    // Stores the phone number for SMS notifications.
    public void updatePhone(int userId, String phoneNumber) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("phone", phoneNumber);

        db.update(
                TABLE_USERS,
                values,
                "id=?",
                new String[]{String.valueOf(userId)}
        );
    }

    public String getPhone(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{"phone"},
                "id=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );

        String phoneNumber = null;

        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(
                    cursor.getColumnIndexOrThrow("phone")
            );
        }

        cursor.close();

        return phoneNumber;
    }

    // CREATE
    public long addWeight(int userId, String date, double weight) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("date", date);
        values.put("weight", weight);

        return db.insert(TABLE_WEIGHTS, null, values);
    }

    // READ
    public Cursor getAllWeights(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_WEIGHTS,
                null,
                "user_id=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "id DESC"
        );
    }

    // UPDATE
    public int updateWeight(int weightId, String date, double weight) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);

        return db.update(
                TABLE_WEIGHTS,
                values,
                "id=?",
                new String[]{String.valueOf(weightId)}
        );
    }

    // DELETE
    public int deleteWeight(int weightId) {

        SQLiteDatabase db = getWritableDatabase();

        return db.delete(
                TABLE_WEIGHTS,
                "id=?",
                new String[]{String.valueOf(weightId)}
        );
    }

    public double getLatestWeight(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_WEIGHTS,
                new String[]{"weight"},
                "user_id=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "id DESC",
                "1"
        );

        double latestWeight = -1;

        if (cursor.moveToFirst()) {
            latestWeight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("weight")
            );
        }

        cursor.close();

        return latestWeight;
    }

    public void setGoalWeight(int userId, double goalWeight) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goalWeight);

        db.insertWithOnConflict(
                TABLE_GOALS,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE
        );
    }

    public double getGoalWeight(int userId) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_GOALS,
                new String[]{"goal_weight"},
                "user_id=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );

        double goalWeight = -1;

        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("goal_weight")
            );
        }

        cursor.close();

        return goalWeight;
    }
}