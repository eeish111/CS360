package com.example.jquinatamodule3;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameText;
    private EditText passwordText;

    private TextView textCapsLock;

    private Button buttonLogin;
    private Button buttonSignUp;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);

        textCapsLock = findViewById(R.id.textCapsLock);

        buttonLogin = findViewById(R.id.buttonLogin);
        buttonSignUp = findViewById(R.id.buttonSignUp);

        buttonLogin.setOnClickListener(v -> loginUser());
        buttonSignUp.setOnClickListener(v -> createAccount());

        passwordText.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count) {

                if (s.length() == 0) {

                    textCapsLock.setVisibility(View.GONE);
                    return;
                }

                char lastCharacter =
                        s.charAt(s.length() - 1);

                if (Character.isLetter(lastCharacter)
                        && Character.isUpperCase(lastCharacter)) {

                    textCapsLock.setVisibility(View.VISIBLE);

                } else {

                    textCapsLock.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void createAccount() {

        String username =
                usernameText.getText().toString().trim();

        String password =
                passwordText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        long result =
                databaseHelper.createUser(
                        username,
                        password
                );

        if (result != -1) {

            Toast.makeText(
                    this,
                    "Account created successfully.",
                    Toast.LENGTH_SHORT
            ).show();

            int userId =
                    databaseHelper.checkUser(
                            username,
                            password
                    );

            openNextScreen(userId);

        } else {

            Toast.makeText(
                    this,
                    "That username already exists.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void loginUser() {

        String username =
                usernameText.getText().toString().trim();

        String password =
                passwordText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter your username and password.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int userId =
                databaseHelper.checkUser(
                        username,
                        password
                );

        if (userId != -1) {

            openNextScreen(userId);

        } else {

            Toast.makeText(
                    this,
                    "Incorrect username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void openNextScreen(int userId) {

        SharedPreferences preferences =
                getSharedPreferences(
                        "app_settings",
                        MODE_PRIVATE
                );

        boolean smsSetupComplete =
                preferences.getBoolean(
                        "sms_setup_complete_" + userId,
                        false
                );

        Intent intent;

        if (smsSetupComplete) {

            intent =
                    new Intent(
                            this,
                            WeightActivity.class
                    );

        } else {

            intent =
                    new Intent(
                            this,
                            SmsActivity.class
                    );
        }

        intent.putExtra(
                "USER_ID",
                userId
        );

        startActivity(intent);
    }
}